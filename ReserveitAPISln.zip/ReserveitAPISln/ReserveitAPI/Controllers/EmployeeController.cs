﻿using Microsoft.AspNetCore.Mvc;
using ReserveitAPI.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ReserveitAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        db dbop = new db();
        string msg = string.Empty;
        
        [HttpGet]
        public List<Employee> Get()
        {
            Employee emp = new Employee();
            emp.type = "get";
            DataSet ds = dbop.EmployeeGet(emp, out msg);
            List<Employee> list = new List<Employee>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                list.Add(new Employee
                {
                    EmployeeId = Convert.ToInt32(dr["EmployeeId"]),
                    EmployeeEmail = dr["EmployeeEmail"].ToString(),
                    EmployeeName = dr["EmployeeName"].ToString(),
                    EmployeeDesignation = dr["EmployeeDesignation"].ToString(),

                });
            }
            return list;
        }

        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        public List<Employee> Get(int id)
        {
            Employee emp = new Employee();
            emp.EmployeeId=id;
            emp.type = "getid";
            DataSet ds = dbop.EmployeeGet(emp, out msg);
            List<Employee> list = new List<Employee>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                list.Add(new Employee
                {
                    EmployeeId = Convert.ToInt32(dr["EmployeeId"]),
                    EmployeeEmail = dr["EmployeeEmail"].ToString(),
                    EmployeeName = dr["EmployeeName"].ToString(),
                    EmployeeDesignation = dr["EmployeeDesignation"].ToString(),

                });
            }
            return list;
        }

        // POST api/<EmployeeController>
        [HttpPost]
        public string Post([FromBody] Employee emp)
        {
            string msg = string.Empty;
            try
            {
                msg = dbop.EmployeeOpt(emp);
            }
            catch (Exception ex)
            {
                msg = ex.Message;
               
            }
            return msg;
        }

        // PUT api/<EmployeeController>/5
        [HttpPut("(id)")]
        public string Update([FromBody] Employee emp)
        {
            string msg = string.Empty;
            try
            {
                msg = dbop.EmployeeOpt(emp);
            }
            catch (Exception ex)
            {
                msg = ex.Message;

            }
            return msg;
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            string msg = string.Empty;
            try
            {
                Employee emp = new Employee();
                emp.EmployeeId = id;
                emp.type = "delete";
                msg = dbop.EmployeeOpt(emp);
            }
            catch (Exception ex)
            {
                msg = ex.Message;

            }
            return msg;
        }
    }
}
