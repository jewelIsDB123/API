﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReserveitAPI.Model
{
    public class Employee
    {
        public int EmployeeId { get; set; } =0;
        public string EmployeeEmail { get; set; } = "";
        public string EmployeeName { get; set; } = "";
        public string EmployeeDesignation { get; set; } = "";
        public string type { get; set; } = "";
    }
}
